package ru.itis.aivar;

import org.jgrapht.graph.DefaultWeightedEdge;
import org.jungrapht.visualization.VisualizationViewer;
import org.jungrapht.visualization.layout.algorithms.KKLayoutAlgorithm;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class MinimalVisualization {

    private MinimalVisualization() throws IOException {

        VisualizationViewer<Point, DefaultWeightedEdge> vv =
                VisualizationViewer.builder(Main.getGraph())
                        .viewSize(new Dimension(700, 700))
                        .layoutAlgorithm(new KKLayoutAlgorithm<>())
                        .build();

        // create a frame to hold the graph visualization
        final JFrame frame = new JFrame();
        frame.getContentPane().add(vv.getComponent());
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) throws IOException {
        System.setProperty("java.awt.headless", "false");
        new MinimalVisualization();
    }
}
