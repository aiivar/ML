package ru.itis.aivar;

import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultUndirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.nio.Attribute;
import org.jgrapht.nio.DefaultAttribute;
import org.jgrapht.nio.dot.DOTExporter;

import java.io.StringWriter;
import java.io.Writer;
import java.util.*;
import java.util.stream.Collectors;

public class GraphCluster {

    protected DefaultUndirectedWeightedGraph<Point, DefaultWeightedEdge> graph;

    protected Set<Point> processedPoints;

    protected Set<DeletedEdge> deletedEdges = new HashSet<>();

    protected boolean graphFound = false;

    public GraphCluster(DefaultUndirectedWeightedGraph<Point, DefaultWeightedEdge> graph) {
        this.graph = graph;
        this.processedPoints = new HashSet<>();
    }

    public String toGraphvizFormat() {
        DOTExporter<Point, DefaultWeightedEdge> exporter = new DOTExporter<>(
                v -> String.valueOf(v.getId())
        );
        exporter.setVertexAttributeProvider((v) -> {
            Map<String, Attribute> map = new LinkedHashMap<>();
            map.put("label", DefaultAttribute.createAttribute(v.getId()));
            return map;
        });
        Writer writer = new StringWriter();
        exporter.exportGraph(graph, writer);
        return writer.toString();
    }

    public void findClusters(int k) {
        if (!graphFound) {
            throw new IllegalStateException();
        }
        deleteMaxEdges(k);
    }

    protected void deleteMaxEdges(int k) {
        if (k < 1) {
            throw new IllegalArgumentException();
        }
        int toRemove = k - 1;
        var edges = graph.edgeSet().stream().sorted(Comparator.comparingDouble(graph::getEdgeWeight)).toList();
        for (int i = edges.size() - 1; i > edges.size() - k; i--) {
            deletedEdges.add(new DeletedEdge(edges.get(i), graph.getEdgeWeight(edges.get(i))));
            graph.removeEdge(edges.get(i));
        }
    }

    protected void buildGraph() {
        var nextPoint = getStartPoint();
        while (processedPoints.size() != graph.vertexSet().size() && nextPoint != null) {
            processedPoints.add(nextPoint);
            nextPoint = processPoint(nextPoint);
        }
        graphFound = true;
    }

    protected Point processPoint(Point point) {
        var closestPoint = findClosestPoint(point);
        if (closestPoint == null) {
            return null;
        }
        var edge = graph.addEdge(point, closestPoint);
        graph.setEdgeWeight(edge, point.distance(closestPoint));
        return closestPoint;
    }

    protected Point findClosestPoint(Point point) {
        var points = graph.vertexSet();
        Point minPoint = null;
        double minDist = Double.MAX_VALUE;
        for (Point gPoint : points) {
            if (processedPoints.contains(gPoint) || point.equals(gPoint)) {
                continue;
            }
            double distance = point.distance(gPoint);
            if (distance < minDist) {
                minDist = distance;
                minPoint = gPoint;
            }
        }
        return minPoint;
    }

    protected Point getStartPoint() {
        return graph.vertexSet().stream().findFirst().orElseThrow(IllegalStateException::new);
    }

    public boolean addVertex(Point point) {
        return graph.addVertex(point);
    }

    public DefaultUndirectedWeightedGraph<Point, DefaultWeightedEdge> getGraph() {
        return graph;
    }

    public void setGraph(DefaultUndirectedWeightedGraph<Point, DefaultWeightedEdge> graph) {
        this.graph = graph;
    }

    public Set<Point> getProcessedPoints() {
        return processedPoints;
    }

    public void setProcessedPoints(Set<Point> processedPoints) {
        this.processedPoints = processedPoints;
    }

    public Set<DeletedEdge> getDeletedEdges() {
        return deletedEdges;
    }

    public void setDeletedEdges(Set<DeletedEdge> deletedEdges) {
        this.deletedEdges = deletedEdges;
    }
}
